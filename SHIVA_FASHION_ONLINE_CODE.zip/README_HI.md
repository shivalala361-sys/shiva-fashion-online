# SHIVA FASHION ONLINE — Starter Website

## What's included
- `public/index.html`: responsive storefront for T-shirts and jackets
- `server.js`: Node.js/Express backend that creates Razorpay orders and verifies checkout signatures
- `.env.example`: template for private credentials

## Important
This is a starter/demo, not a fully production-ready store. Product images, sizes, shipping, refund policy, privacy notice, database/order records, stock management, and fulfilment integration still need to be added. Do not ship any order based only on a browser success message. Verify payment status server-side and save the order in a database first.

Never put `RAZORPAY_KEY_SECRET`, Qikink access tokens, or other secrets in HTML/JavaScript that runs in the browser. Never send secret keys in chat.

## Run locally
1. Install Node.js (LTS) on a computer.
2. Open a terminal in this folder.
3. Copy `.env.example` to `.env`.
4. Add your Razorpay **test** Key ID and Key Secret to `.env`.
5. Run:
   ```bash
   npm install
   npm start
   ```
6. Open `http://localhost:3000`.

For a local demo, the `public` folder contains the website. `server.js` must run too; opening `index.html` directly will not enable checkout.

## Change product information
Product names and prices appear in both:
- `public/index.html` (what customers see)
- `server.js` (`CATALOG`, which determines the trusted amount)

Keep the prices identical in both files. Replace emoji product art with photos you own or have permission to use.

## Before going live
- Complete Razorpay onboarding and use live keys only when approved.
- Host this Node.js app on a server that supports Node.js and HTTPS.
- Set environment variables in the host dashboard; do not upload `.env`.
- Add a database and persistent order records.
- Verify payment status through Razorpay's server API before fulfilling an order.
- Add shipping, delivery, cancellation, returns/refunds, privacy, and contact details.
- For Qikink, integrate order fulfilment server-side only after payment verification. Do not expose Qikink ClientId/access token in the browser.
- If you are under 18, ask a parent/guardian to help with payment-provider account setup and business/legal requirements.
