require("dotenv").config();
const express = require("express");
const Razorpay = require("razorpay");
const crypto = require("crypto");
const path = require("path");

const app = express();
app.use(express.json({ limit: "100kb" }));
app.use(express.static(path.join(__dirname, "public")));

const PORT = process.env.PORT || 3000;
const keyId = process.env.RAZORPAY_KEY_ID;
const keySecret = process.env.RAZORPAY_KEY_SECRET;

const CATALOG = {
  "tee-black": { name: "Classic Black T-shirt", price: 49900 },
  "tee-white": { name: "Classic White T-shirt", price: 54900 },
  "jacket-brown": { name: "Brown Leather-look Jacket", price: 129900 }
};

function getRazorpay() {
  if (!keyId || !keySecret) throw new Error("Razorpay keys .env file में सेट नहीं हैं।");
  return new Razorpay({ key_id: keyId, key_secret: keySecret });
}

app.post("/api/create-order", async (req, res) => {
  try {
    const { items, customer } = req.body || {};
    if (!Array.isArray(items) || !items.length) return res.status(400).json({ error: "Cart खाली है।" });
    if (!customer || !customer.name || !customer.email || !/^\d{10}$/.test(customer.phone || "") || !customer.address) {
      return res.status(400).json({ error: "कृपया सही customer details भरें।" });
    }
    let amount = 0;
    for (const item of items) {
      const product = CATALOG[item.id];
      const qty = Number(item.quantity);
      if (!product || !Number.isInteger(qty) || qty < 1 || qty > 10) {
        return res.status(400).json({ error: "Cart में invalid product या quantity है।" });
      }
      amount += product.price * qty;
    }
    if (amount > 5000000) return res.status(400).json({ error: "Order amount limit से अधिक है।" });
    const razorpay = getRazorpay();
    const order = await razorpay.orders.create({
      amount, currency: "INR",
      receipt: "sfo_" + Date.now().toString().slice(-10),
      notes: { customer_name: String(customer.name).slice(0, 80), customer_phone: customer.phone }
    });
    res.json({ keyId, orderId: order.id, amount: order.amount, currency: order.currency });
  } catch (err) {
    console.error("Create order error:", err.message);
    res.status(500).json({ error: err.message || "Order create नहीं हो सका।" });
  }
});

app.post("/api/verify-payment", async (req, res) => {
  try {
    const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = req.body || {};
    if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature) {
      return res.status(400).json({ error: "Payment verification details missing हैं।" });
    }
    const expected = crypto.createHmac("sha256", keySecret)
      .update(razorpay_order_id + "|" + razorpay_payment_id).digest("hex");
    const a = Buffer.from(expected, "utf8");
    const b = Buffer.from(razorpay_signature, "utf8");
    if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
      return res.status(400).json({ error: "Payment signature सही नहीं है।" });
    }
    // Production में यहाँ order को database में save करें और fulfilment से पहले
    // Razorpay payment status server-side API से भी confirm करें।
    res.json({ ok: true, orderReference: razorpay_order_id });
  } catch (err) {
    console.error("Verify payment error:", err.message);
    res.status(500).json({ error: "Payment verify नहीं हो सका।" });
  }
});

app.get("/api/health", (_req, res) => res.json({ ok: true }));
app.listen(PORT, () => console.log(`SHIVA FASHION ONLINE running on http://localhost:${PORT}`));
